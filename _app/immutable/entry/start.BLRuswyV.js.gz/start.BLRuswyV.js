import{l as o,a as r}from"../chunks/Cmi3L5FF.js";export{o as load_css,r as start};
